
public class Course {
    String courseName;
    int []marks;

    public Course(String name, int[] arr){
        courseName=name;
        marks=arr;
    }
    
}
